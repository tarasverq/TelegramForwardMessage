using System;
using System.Threading.Tasks;
using NUnit.Framework;
using TLSchema;

namespace TelegramForwardMessage.Tests
{
    public class Tests
    {
        [SetUp]
        public void Setup()
        {
        }

        [Test]
        public async Task Test1()
        {
           
            //Клиент и секрет от него из телеграма
            int clientId = 2428392;
            string clientHash = "fd7753c449cdd516e882a8b744277da3";
            //Телефон без +, иначе не будет работать кеш сессий
            string phone = "79999999999";
            //ID канала откуда копируем сообщение из урла - https://t.me/sdfghjkloiuytyuiouytreujk0987654
            string channelFromUsername = "novosty";
            //ID канала куда копируем сообщение из урла - https://t.me/sdfghjkloiuytyuiouytreujk0987655
            string channelToUsername = "novosti_chat";
                
            ITelegramMessageForwarder messageForwarder = new TelegramMessageForwarder(clientId, clientHash, phone);
            if (await messageForwarder.Initialize())
            {
                Console.WriteLine("Введите код из телеграма");
                //TODO подставить тут код в дебаге
                string code = "1";
                await messageForwarder.SendCode(code);
            }

            TLChannel channelFrom = await messageForwarder.GetChannel(channelFromUsername);
            TLChannel channelTo = await messageForwarder.GetChannel(channelToUsername);

            await messageForwarder.ReplyInDiscussion(channelFrom, channelTo);
            Assert.Pass();
        }
    }
}
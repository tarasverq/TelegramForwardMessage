﻿using System;
using System.Linq;
using System.Threading.Tasks;
using TLSchema;
using TLSchema.Contacts;
using TLSchema.Messages;
using TLSharp;
using TLSharp.Utils;

namespace TelegramForwardMessage
{
    public interface ITelegramMessageForwarder
    {
        Task<bool> Initialize();
        Task SendCode(string code);
        Task<int> Forward(TLChannel channelFrom, TLChat chatTo);
        Task<int> Forward(TLChannel channelFrom, TLChannel channelTo);
        Task<TLChannel> GetChannel(string username);
        Task ReplyTo(TLChannel channelTo, string message, int? replyMsgId = null);
        Task ReplyTo(TLChat chatTo, string message, int? replyMsgId = null);
        Task ReplyInDiscussion(TLChannel channelFrom, TLChannel chatTo);
    }

    public class TelegramMessageForwarder : ITelegramMessageForwarder
    {
        private bool _authorized;
        private readonly string _phone;
        private readonly TelegramClient _client;

        private string _hash;

        public TelegramMessageForwarder(int clientId, string clientHash, string phone)
        {
            _phone = phone;

            _client = new TelegramClient(clientId, clientHash, null, phone);

        }

        /// <summary>
        /// Проверяет авторизацию и отправляет код для логина при необходимости
        /// </summary>
        /// <returns></returns>
        public async Task<bool> Initialize()
        {
            await _client.ConnectAsync();

            if (!_authorized && !_client.IsUserAuthorized())
            {
                _hash = await _client.SendCodeRequestAsync("+" + _phone);
                return true;
            }

            _authorized = true;
            return false;
        }

        /// <summary>
        /// Отправляет код обратно в телегу
        /// </summary>
        /// <param name="code"></param>
        /// <returns></returns>
        public async Task SendCode(string code)
        {
            if (!_authorized)
            {
                TLUser auth = await _client.MakeAuthAsync(_phone, _hash, code);
                _authorized = true;
            }
        }


        /// <summary>
        /// Пересылает последнее сообщение из канала в канал
        /// </summary>
        /// <param name="channelFrom"></param>
        /// <param name="channelTo"></param>
        /// <returns></returns>
        /// <exception cref="UnauthorizedAccessException"></exception>
        public Task<int> Forward(TLChannel channelFrom, TLChannel channelTo)
        {
            if (!_authorized)
                throw new UnauthorizedAccessException("Not authorized");


            TLAbsInputPeer to = new TLInputPeerChannel()
            {
                ChannelId = channelTo.Id,
                AccessHash = channelTo.AccessHash ?? 0
            };

            return ForwardLastMessage(channelFrom, to);
        }

        public Task<int> Forward(TLChannel channelFrom, TLChat chatTo)
        {
            if (!_authorized)
                throw new UnauthorizedAccessException("Not authorized");


            TLAbsInputPeer to = new TLInputPeerChat()
            {
                ChatId = chatTo.Id,
            };

            return ForwardLastMessage(channelFrom, to);
        }

        public async Task<int> ForwardLastMessage(TLChannel channelFrom, TLAbsInputPeer to)
        {
            TLAbsInputPeer from = new TLInputPeerChannel()
            {
                ChannelId = channelFrom.Id,
                AccessHash = channelFrom.AccessHash ?? 0
            };
            TLMessage lastMessage = await GetLastMessage(channelFrom);

            return await ForwardMessage(to, @from, lastMessage.Id);
        }

        private async Task<int> ForwardMessage(TLAbsInputPeer to, TLAbsInputPeer @from, int lastMessageId)
        {
            TLRequestForwardMessages requestForwardMessages = new TLRequestForwardMessages()
            {
                FromPeer = @from,
                ToPeer = to,
                Id = new TLVector<int>() {lastMessageId},
                RandomId = new TLVector<long>() {Helpers.GenerateRandomLong()},
            };

            try
            {
                TLUpdates forwardResult = await _client.SendRequestAsync<TLUpdates>(requestForwardMessages);
                int messageId = ((TLUpdateMessageID) forwardResult.Updates.First(x => x is TLUpdateMessageID)).Id;
                return messageId;
            }
            catch (Exception e)
            {
                //TODO залоггировать ошибку
                throw;
            }
        }

        /// <summary>
        /// Получить последнее сообщение из канала
        /// </summary>
        /// <param name="channelFrom"></param>
        /// <returns></returns>
        private async Task<TLMessage> GetLastMessage(TLChannel channelFrom)
        {
            TLChannelMessages resp = (TLChannelMessages) await _client.GetHistoryAsync(new TLInputPeerChannel()
            {
                ChannelId = channelFrom.Id,
                AccessHash = channelFrom.AccessHash ?? 0,
            }, limit: 1000);

            TLMessage lastMessage = (TLMessage) resp.Messages?.Where(x => x is TLMessage).First();
            return lastMessage;
        }     
        
        private async Task<TLMessage> GetLastForwardMessage(TLChannel channelFrom, int channelId, int postId)
        {
            TLChannelMessages resp = (TLChannelMessages) await _client.GetHistoryAsync(new TLInputPeerChannel()
            {
                ChannelId = channelFrom.Id,
                AccessHash = channelFrom.AccessHash ?? 0,
            }, limit: 100);

            TLMessage lastMessage = (TLMessage) resp.Messages?.Where(x =>
                x is TLMessage message
                && message.FwdFrom?.ChannelId == channelId
                && message.FwdFrom?.ChannelPost == postId
            ).First();
            return lastMessage;
        }


        public async Task ReplyInDiscussion(TLChannel channelFrom, TLChannel chatTo)
        {
            TLMessage lastMessage = await GetLastMessage(channelFrom);
            TLMessage lastChatMessage = await GetLastForwardMessage(chatTo, channelFrom.Id, lastMessage.Id);
            await ReplyTo(chatTo, "Ololo", lastChatMessage.Id);
        }

        /// <summary>
        /// Получить инфу о канале
        /// </summary>
        /// <param name="username"></param>
        /// <returns></returns>
        /// <exception cref="UnauthorizedAccessException"></exception>
        public async Task<TLChannel> GetChannel(string username)
        {
            if (!_authorized)
                throw new UnauthorizedAccessException("Not authorized");
            TLRequestResolveUsername requestResolveUsername = new TLRequestResolveUsername()
            {
                Username = username
            };

            TLResolvedPeer peer = await _client.SendRequestAsync<TLResolvedPeer>(requestResolveUsername);

            TLChannel channel = (TLChannel) peer.Chats.First();
            return channel;
        }

        public Task ReplyTo(TLChannel channelTo, string message, int? replyMsgId = null)
        {
            TLAbsInputPeer to = new TLInputPeerChannel()
            {
                ChannelId = channelTo.Id,
                AccessHash = channelTo.AccessHash ?? 0
            };
            return ReplyTo(to, message, replyMsgId);
        }

        public Task ReplyTo(TLChat chatTo, string message, int? replyMsgId = null)
        {
            TLAbsInputPeer to = new TLInputPeerChat()
            {
                ChatId = chatTo.Id
            };
            return ReplyTo(to, message, replyMsgId);
        }

        private async Task ReplyTo(TLAbsInputPeer to, string message, int? replyMsgId = null)
        {
            var req = new TLRequestSendMessage()
            {
                Peer = to,
                Message = message,
                RandomId = Helpers.GenerateRandomLong(),
                ReplyToMsgId = replyMsgId
            };
            await _client.SendRequestAsync<TLUpdates>(req);
        }
    }
}